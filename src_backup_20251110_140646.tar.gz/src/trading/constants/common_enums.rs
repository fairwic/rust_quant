/// btc永续合约
pub const BTC_SWAP_INST_ID: &str = "BTC-USDT-SWAP";
/// eth永续合约
pub const ETH_SWAP_INST_ID: &str = "ETH-USDT-SWAP";
/// sol币永续合约
pub const SOL_SWAP_INST_ID: &str = "SOL-USDT-SWAP";
/// xrp币永续合约
pub const XRP_SWAP_INST_ID: &str = "XRP-USDT-SWAP";
/// ada币永续合约
pub const ADA_SWAP_INST_ID: &str = "ADA-USDT-SWAP";
/// dot币永续合约
pub const DOT_SWAP_INST_ID: &str = "DOT-USDT-SWAP";
/// link币永续合约
pub const LINK_SWAP_INST_ID: &str = "LINK-USDT-SWAP";
